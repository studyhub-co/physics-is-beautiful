import Airtable from 'airtable';

export default new Airtable({ apiKey: 'keyJugfwdJzOyL7Aa' });
