export const INITIAL_SERVER_STATE = {
  status: 'initializing',
  containerStatus: 'initializing',
  error: undefined,
  hasUnrecoverableError: false,
  ports: [],
};
